export default class BasePage {

};
